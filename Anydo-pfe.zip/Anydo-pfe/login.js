function validation()
{
var Us = document . login .email.value;
var Ps = document . login .password.value;
if(Us.length=="" && Ps.length=="" ){
alert("Please enter your gmail and password first");
return false
}
else{
if(Us.length==""  ){
    alert("Please enter your gmail ");
    return false
    }
if(Ps.length==""  ){
    alert("Please enter your password ");
    return false
    }
}




}