<?php
    include('conne.php');
    session_start();


    if (isset($_POST['submit'])){ 
        $categoris = $_POST['categoris'];
        $location = $_POST['location'];
        $phone = $_POST['phone'];
        $userid = $_SESSION['user']['id'];
    


        $sql =  " INSERT INTO ouvrier (catégorie, location, telephone, userid) VALUES ('$categoris', '$location', '$phone', '$userid') " ;
        $result = mysqli_query($con, $sql);
        if($result){
            
            $sql1 =  " UPDATE utilisateur SET ove_or_cl = 1 WHERE id = $userid " ;
            $result1 = mysqli_query($con, $sql1);
            $_SESSION['user']['ove_or_cl']=1;

            $sql2 = "SELECT * FROM utilisateur WHERE id = '$userid'"; 
            $result2 = mysqli_query($con, $sql2) ;
            $info = mysqli_fetch_assoc($result2);


            $sql3 = "SELECT * FROM ouvrier WHERE userid = '$userid'"; 
    $result3 = mysqli_query($con, $sql3) ;
    $info1 = mysqli_fetch_assoc($result3);

    $_SESSION['user']['id']=$info['id'];
    $_SESSION['user']['ove_or_cl']=$info['ove_or_cl'];
    $_SESSION['user']['nom']=$info['nom'];
    $_SESSION['user']['prenom']=$info['prenom'];
    $_SESSION['user']['email']=$info['email'];
    $_SESSION['user']['tel']=$info1['telephone'];
    $_SESSION['user']['location']=$info1['location'];
    $_SESSION['user']['catégorie']=$info1['catégorie'];
    $_SESSION['user']['profile_img']=$info1['profile_img'];
            header("Location:index.php");
        }else{
            echo  '<script>
                    window.location.href="signupw.html";
                    alert("error");
                </script>' ;
        }
    
    
    


         }
?>