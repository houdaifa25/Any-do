<?php
session_start();

include('conne.php');
$email = $_POST['email'];
$password = $_POST['password'];

$email = stripcslashes($email);
$password = stripcslashes($password);

$email = mysqli_real_escape_string($con,$email);
$password = mysqli_real_escape_string($con,$password);

$sql = "SELECT * FROM utilisateur WHERE email = '$email' AND password = '$password'"; 
$result = mysqli_query($con, $sql) ;
$count = mysqli_num_rows($result);



if($count == true ){
    
    $info = mysqli_fetch_assoc($result);
    $id = $info['id'];
    $sql1 = "SELECT * FROM ouvrier WHERE userid = '$id'"; 
    $result1 = mysqli_query($con, $sql1) ;
    $info1 = mysqli_fetch_assoc($result1);

    $_SESSION['user']['id']=$info['id'];
    $_SESSION['user']['ove_or_cl']=$info['ove_or_cl'];
    $_SESSION['user']['nom']=$info['nom'];
    $_SESSION['user']['prenom']=$info['prenom'];
    $_SESSION['user']['email']=$info['email'];
    $_SESSION['user']['tel']=$info1['telephone'];
    $_SESSION['user']['location']=$info1['location'];
    $_SESSION['user']['catégorie']=$info1['catégorie'];
    $_SESSION['user']['profile_img']=$info1['profile_img'];
header('location:index.php');
}  
else{
    header('location:login.php');
?>
<script>
alert ('Incorrect username or password');
</script> 
<?php
//INSERT INTO `utilisateur` (`id`, `nom`, `prenom`, `password`, `email`) VALUES (NULL, 'yakoub', 'bouloudenine', '12345', 'bouloudenine@gmail.com');



}




?>