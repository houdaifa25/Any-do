<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="profile2.js" defer></script> 
    <title>Personal Portfolio Website designing -K2inofocom</title>
    <!---external css ---->
    <link rel="stylesheet" href="style-p14.css">
    <!---font awesome cdn for font icons---->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>

<?php session_start(); ?>
<?php require_once('profile_showphp.php') ?>
<?php if(isset($_SESSION['user'])) { ?>






   <header>
   <?php if ($_SESSION['profiles']['catégorie']== 'plumbing')  {  ?>
      <a href ="index m.php"><img src = "../assets/img/back.webp" ></a>
                            <?php } else { if ($_SESSION['profiles']['catégorie']== 'building') { ?>
                              <a href ="building.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'electricite') { ?>
                              <a href ="electricite.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'Gardening') { ?>
                              <a href ="Gardening.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'carmechanics') { ?>
                              <a href ="carmechanics.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'painting') { ?>
                              <a href ="painting.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'joinery') { ?>
                              <a href ="joinery.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'stitching') { ?>
                              <a href ="stitching.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'welding') { ?>
                              <a href ="welding.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'plastering') { ?>
                              <a href ="plastering.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'RepairBusiness') { ?>
                              <a href ="RepairBusiness.php"><img src = "../assets/img/back.webp" ></a>
                              <?php } else { if ($_SESSION['profiles']['catégorie']== 'Guttercleaning') { ?>
                              <a href ="Guttercleaning.php"><img src = "../assets/img/back.webp" ></a>
                                <?php } }}}}}}}}}}} ?>
                            

       <div class="mywork">
         <h2> Look at my works :</h2>
       </div>


   </header>
   










   <div class="container">
       <div class="profile-card" id="profile-card"> 
        <div class="star">
            <h2><?php echo $_SESSION['profiles']['Evaluation'] ?></h2>
            <img src="../assets/img/star-icon.webp" alt="">
        </div>
         <div class="staticon"></div>
            <div class="profile-pic">
                
                <img src="../assets/img/<?php echo $_SESSION['profiles']['profile_img'] ?>" alt="user avatar">
            </div>

            <div class="profile-details">
                 <div class="intro">
                    <h2><?php echo $_SESSION['profiles']['nom']  ?> <?php echo $_SESSION['profiles']['prenom']  ?></h2>
                    <h4><?php echo $_SESSION['profiles']['catégorie'] ?></h4>
                    
                 </div>

                 <div class="contact-info">
                    <div class="row">
                         <div class="icon">
                            <i class="fa fa-phone"  style="color:var(--dark-magenta)"></i>
                         </div>
                         <div class="content">
                            <span>Phone</span>
                            <h5><?php echo $_SESSION['profiles']['tel'] ?></h5>
                         </div>
                    </div>

                    <div class="row">
                        <div class="icon">
                           <i class="fa fa-envelope-open"  style="color:var(--light-green)"></i>
                        </div>
                        <div class="content">
                           <span>Email</span>
                           <h5><?php echo $_SESSION['profiles']['email']  ?></h5>
                        </div>
                   </div>
    
                   <div class="row">
                    <div class="icon">
                       <i class="fa fa-map-marker"  style="color:var(--light-purple)"></i>
                    </div>
                    <div class="content">
                       <span>Location</span>
                       <h5><?php echo $_SESSION['profiles']['location']  ?></h5>
                    </div>
                 </div>

            </div>
            <div class="evaluation">
            <form method="POST">
               <input  class="evalN" type="number" name="evalN" max="5" min="0">
               <img src="../assets/img/star-icon.webp" alt=""><br>
               <input class="evalbtn" type="submit" name="evalbtn">
            </form>
            </div>
            </div>
       </div>



       <div class="postlist">
       <?php foreach ($res as $row) {  ?>
       <div class="postcard">
       <a href="./profile_show.php?msg=<?php echo $_SESSION['profiles']['nom'] ?>&msg1=<?php echo $row['posts_img'] ?>"><img src="../assets/img/<?php echo $row['posts_img'] ?>" alt=""></a>
       </div>
       <?php } ?>
       </div>


      


       <?php 
       if($_SESSION['profiles']['stat']==0){
       echo "<script>
          const staticon = document.querySelector('.staticon');
          staticon.style.backgroundColor ='#770101';
       </script>";}else{
           echo "<script>
          const staticon = document.querySelector('.staticon');
          staticon.style.backgroundColor ='#017736';
       </script>";
       }
       ?>
      <?php if(isset($_REQUEST['msg1'])) { ?>
         <div class="focusimg">
            <img src="../assets/img/<?php echo $_SESSION['imgfocus']['name'] ?>" alt="photo">
            
         </div>
         <div class="closefocus">
         <a href="./profile_show.php?msg=<?php echo $_SESSION['profiles']['nom'] ?>"><img src="../assets/img/cros.png" alt=""></a>
         </div>
         <?php } ?>
       <?php }else{ 
    header('location:login.php');
  }
    ?>
      
</body>
</html>