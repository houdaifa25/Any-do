const editimgbtn = document.querySelector('.profile-card img');

const editimgdiv = document.getElementById('updatep');

editimgbtn.addEventListener("click", ()=>{editimgdiv.style.display= "block";});


const closeeditdiv = document.querySelector('.close');
 
closeeditdiv.addEventListener("click", ()=>{editimgdiv.style.display= "none";});



const addimgbtn = document.querySelector('.postcardadd');

const addimgdiv = document.getElementById('addpost');

addimgbtn.addEventListener("click", ()=>{addimgdiv.style.display= "block";});


const closeeditdiv1 = document.querySelector('#close');
 
closeeditdiv1.addEventListener("click", ()=>{addimgdiv.style.display= "none";});



const editinobtn = document.querySelector('.download-btn');

const editinfodiv = document.getElementById('editinfo');

editinobtn.addEventListener("click", ()=>{editinfodiv.style.display="flex";});

const closeeditdiv2 = document.querySelector('#close1');
 
closeeditdiv2.addEventListener("click", ()=>{editinfodiv.style.display= "none";});



























