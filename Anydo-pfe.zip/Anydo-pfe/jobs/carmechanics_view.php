<?php 
include("../conne.php");
$catégorie = 'carmechanics';
$sql = "CREATE OR REPLACE VIEW carmechanics_view AS
SELECT *
FROM utilisateur
INNER JOIN ouvrier ON utilisateur.id = ouvrier.userid;";
$result = mysqli_query($con, $sql);
// الشروط لازم نفس الخدمة
$sql1 = "SELECT * FROM carmechanics_view WHERE catégorie = '$catégorie'";
$result1 = mysqli_query($con, $sql1);

