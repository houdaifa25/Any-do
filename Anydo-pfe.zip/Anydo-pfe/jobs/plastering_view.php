<?php 
include("../conne.php");
$catégorie = 'plastering';
$sql = "CREATE OR REPLACE VIEW plastering_view AS
SELECT *
FROM utilisateur
INNER JOIN ouvrier ON utilisateur.id = ouvrier.userid;";
$result = mysqli_query($con, $sql);
// الشروط لازم نفس الخدمة
$sql1 = "SELECT * FROM plastering_view WHERE catégorie = '$catégorie'";
$result1 = mysqli_query($con, $sql1);

