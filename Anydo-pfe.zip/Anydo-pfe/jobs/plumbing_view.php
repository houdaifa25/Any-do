<?php 
include("../conne.php");
$plumbing = "plumbing";
$sql = "CREATE OR REPLACE VIEW plumbing_view AS
SELECT *
FROM utilisateur
INNER JOIN ouvrier ON utilisateur.id = ouvrier.userid;";
$result = mysqli_query($con, $sql);
// الشروط لازم نفس الخدمة
$sql1 = "SELECT * FROM plumbing_view WHERE catégorie = '$plumbing'";
$result1 = mysqli_query($con, $sql1);

