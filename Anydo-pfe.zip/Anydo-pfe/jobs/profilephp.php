
<?php 
include "../conne.php";
$id = $_SESSION['user']['id'];

if(isset($_REQUEST['upbtn'])){
if($_SERVER["REQUEST_METHOD"] == "POST"){
$imgn=$_FILES["upimg"]["name"];
    $temp=$_FILES["upimg"]["tmp_name"];
    $folder="../assets/img/".$imgn;
    move_uploaded_file($temp,$folder);
}
$id = $_SESSION['user']['id'];
$sql = " UPDATE ouvrier SET profile_img = '$imgn' WHERE userid = $id" ;
$res= mysqli_query($con,$sql);
if($res){
    $_SESSION['user']['profile_img']=$imgn;
}
}



if(isset($_REQUEST['upbtn1'])){
    if($_SERVER["REQUEST_METHOD"] == "POST"){
    $imgn=$_FILES["uppost"]["name"];
        $temp=$_FILES["uppost"]["tmp_name"];
        $folder="../assets/img/".$imgn;
        move_uploaded_file($temp,$folder);
    }
    $id = $_SESSION['user']['id'];
    $sql = " INSERT INTO posts (posts_img,userid_over) VALUES ('$imgn','$id')" ;
    $res= mysqli_query($con,$sql);
    
    }


    if(isset($_REQUEST['editbtn'])){
        $phone=$_REQUEST['phone'];
        $email=$_REQUEST['email'];
        $location=$_REQUEST['location'];
        $id = $_SESSION['user']['id'];
        $sql = " UPDATE ouvrier SET telephone = '$phone' , location = '$location' WHERE userid = $id" ;
        $res= mysqli_query($con,$sql);
        $sql1 = " UPDATE utilisateur SET email = '$email' WHERE id = $id" ;
        $res1= mysqli_query($con,$sql1);
        if($res){
            $_SESSION['user']['tel']=$phone;
            $_SESSION['user']['email']=$email;
            $_SESSION['user']['location']=$location;
        }
    }




    if(isset($_REQUEST['statbtn'])){
        $stat=$_REQUEST['stat'];
        $sql = " UPDATE ouvrier SET stat = '$stat' WHERE userid = $id" ;
        $res= mysqli_query($con,$sql);

        
    }




    


    $id = $_SESSION['user']['id'];



    // الشروط لازم نفس الخدمة
    $sql1 = "SELECT * FROM posts WHERE userid_over = '$id'";
    $result1 = mysqli_query($con, $sql1);
    

