
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gardening</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
</head>

<body>
    <?php include("Gardening_view.php") ?>
    <style>
        body {
    min-height: 100vh;
    background: url(images/html_table-1.jpg) center / cover;
    display: flex;
    justify-content: center;
    align-items: center;
      }
    </style>
    <main class="table" id="customers_table">
        <section class="table__header">
            <h1>Gardening workers liste</h1>
            <div class="input-group">
                <input type="search" placeholder="Search Data...">
                <img src="images/search.png" alt="">
            </div>
        </section>
        <section class="table__body">
            <table>
                <thead>
                    <tr>
                        <th> </th>
                        <th> Worker </th>
                        <th> Location </th>
                        <th> Contact</th>
                        <th> Active</th>
                        <th> Rate </th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($result1 as $row) {  ?>
                    <tr>
                        <td> </td>
                        <td> <img src="../assets/img/<?php echo $row['profile_img'] ?>" alt=""><a href="./profile_show.php?msg=<?php echo $row['nom'] ?>"><?php echo $row['nom'] ?> <?php echo $row['prenom'] ?> </a></td>
                        <td> <?php echo $row['location'] ?> </td>
                        <td> <?php echo $row['telephone'] ?></td>
                        <td>
                            <?php if ($row['stat'] == 1)  {  ?>
                            <p class="status delivered">Active</p>
                            <?php } else {  ?>
                                <p class="status cancelled ">Not active</p>
                                <?php } ?>
                        </td>
                        <td> <strong><?php echo $row['Evaluation'] ?></strong></td>
                    </tr>
                  
                   <?php } ?>
                     
                </tbody>
            </table>
        </section>
    </main>
    <div class="back">
    <a href ="../index.php">  <img src="../assets/img/back.webp"></a>
</div>
    <script src="script.js"></script>

</body>

</html>
