<?php 
include "../conne.php";

if(isset($_GET['msg'])){

$name=$_GET['msg'];


$sql = "SELECT * FROM utilisateur WHERE nom = '$name'";
    $result = mysqli_query($con, $sql);
    if($result){
    $resultt = mysqli_fetch_assoc($result);
    
    $_SESSION['profiles']['nom']=$resultt['nom'];
    $_SESSION['profiles']['prenom']=$resultt['prenom'];
    $_SESSION['profiles']['email']=$resultt['email'];
    $_SESSION['profiles']['id']=$resultt['id'];
    $id=$_SESSION['profiles']['id'];
    }

    $sql1 = "SELECT * FROM ouvrier WHERE userid = '$id'";
    $result1 = mysqli_query($con, $sql1);
    if($result1){
        $resultt1 = mysqli_fetch_assoc($result1);
        
        $_SESSION['profiles']['tel']=$resultt1['telephone'];
        $_SESSION['profiles']['location']=$resultt1['location'];
        $_SESSION['profiles']['profile_img']=$resultt1['profile_img'];
        $_SESSION['profiles']['stat']=$resultt1['stat'];
        $_SESSION['profiles']['Evaluation']=$resultt1['Evaluation'];
        $_SESSION['profiles']['catégorie']=$resultt1['catégorie'];

        }


        $sql2 = "SELECT * FROM posts WHERE userid_over = '$id'";
    $res = mysqli_query($con, $sql2);
}

if(isset($_REQUEST['evalbtn'])){

    $num=$_REQUEST['evalN'];

    $userid=$_SESSION['user']['id'];

    $sql7="SELECT * FROM evaluiation WHERE evaluiation.eva_ouvid= $id AND evaluiation.eva_userid= $userid";
        $result7 = mysqli_query($con, $sql7);
        $count = mysqli_num_rows($result7);

        if($count==0){
    $sql3 =  " INSERT INTO evaluiation (eva_userid, eva_ouvid, evaluer) VALUES ('$userid', '$id', '$num') " ;
        $result3 = mysqli_query($con, $sql3);
    }else{
        echo "<script> alert('you cant')</script>";
    }

        $sql4="SELECT SUM(evaluer) AS some FROM evaluiation WHERE evaluiation.eva_ouvid= $id";
        $result4 = mysqli_query($con, $sql4);
        $resultt4 = mysqli_fetch_assoc($result4);

        $sql5="SELECT COUNT(evaluer) AS count FROM evaluiation WHERE evaluiation.eva_ouvid = $id";
        $result5 = mysqli_query($con, $sql5);
        $resultt5 = mysqli_fetch_assoc($result5);

        $ev= $resultt4['some']/$resultt5['count'];


        
        
        

        if($count==0){

        $sql6 = "UPDATE ouvrier SET Evaluation = '$ev' WHERE userid = $id" ;
        $res6= mysqli_query($con,$sql6);
            }else{
                echo "<script> alert('you cant')</script>";
            }
}

if(isset($_GET['msg1'])){

    $name=$_GET['msg1'];
    $_SESSION['imgfocus']['name']=$name;

}

