<?php 
include("../conne.php");
$catégorie = 'electricite';
$sql = "CREATE OR REPLACE VIEW electricite_view AS
SELECT *
FROM utilisateur
INNER JOIN ouvrier ON utilisateur.id = ouvrier.userid;";
$result = mysqli_query($con, $sql);
// الشروط لازم نفس الخدمة
$sql1 = "SELECT * FROM electricite_view WHERE catégorie = '$catégorie'";
$result1 = mysqli_query($con, $sql1);

