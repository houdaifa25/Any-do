<?php 
include("../conne.php");
$catégorie = 'building';
$sql = "CREATE OR REPLACE VIEW building_view AS
SELECT *
FROM utilisateur
INNER JOIN ouvrier ON utilisateur.id = ouvrier.userid;";
$result = mysqli_query($con, $sql);
// الشروط لازم نفس الخدمة
$sql1 = "SELECT * FROM building_view WHERE catégorie = '$catégorie'";
$result1 = mysqli_query($con, $sql1);

