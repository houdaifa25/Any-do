<?php 
include("../conne.php");
$catégorie = 'stitching';
$sql = "CREATE OR REPLACE VIEW stitching_view AS
SELECT *
FROM utilisateur
INNER JOIN ouvrier ON utilisateur.id = ouvrier.userid;";
$result = mysqli_query($con, $sql);
// الشروط لازم نفس الخدمة
$sql1 = "SELECT * FROM stitching_view WHERE catégorie = '$catégorie'";
$result1 = mysqli_query($con, $sql1);

