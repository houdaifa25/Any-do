<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="profile2.js" defer></script> 
    <title>Personal Portfolio Website designing -K2inofocom</title>
    <!---external css ---->
    <link rel="stylesheet" href="style-p14.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,1,0" />
    <script src="chat.js" defer></script>
    <!---font awesome cdn for font icons---->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>

<?php session_start(); ?>
<?php require_once('profilephp.php') ?>
<?php if(isset($_SESSION['user'])) { ?>
   <header>
      <a href ="../index.php"><img src = "../assets/img/back.webp" ></a>
      <div class="mywork">
         <h2> Look at my works :</h2>
       </div>
   </header>
   <div class="container">
       <div class="profile-card" id="profile-card"> 
         <div class="staticon"></div>
            <div class="profile-pic">
                
                <img src="../assets/img/<?php echo $_SESSION['user']['profile_img'] ?>" alt="user avatar">
            </div>

            <div class="profile-details">
                 <div class="intro">
                    <h2><?php echo $_SESSION['user']['nom']  ?> <?php echo $_SESSION['user']['prenom']  ?></h2>
                    <h4><?php echo $_SESSION['user']['catégorie'] ?></h4>
                    <div class="social">
                     <form method="POST">
                       <input required class="radio" type="radio" name="stat" value="1">Active
                       <input required class="radio" type="radio" name="stat" value="0">Not Active</br>
                       <input class="statbtn" type="submit" name="statbtn" value="Valide">
                       </form>
                    </div>
                 </div>
                 

                 <div class="contact-info">
                    <div class="row">
                         <div class="icon">
                            <i class="fa fa-phone"  style="color:var(--dark-magenta)"></i>
                         </div>
                         <div class="content">
                            <span>Phone</span>
                            <h5><?php echo $_SESSION['user']['tel'] ?></h5>
                         </div>
                    </div>

                    <div class="row">
                        <div class="icon">
                           <i class="fa fa-envelope-open"  style="color:var(--light-green)"></i>
                        </div>
                        <div class="content">
                           <span>Email</span>
                           <h5><?php echo $_SESSION['user']['email']  ?></h5>
                        </div>
                   </div>
    
                   <div class="row">
                    <div class="icon">
                       <i class="fa fa-map-marker"  style="color:var(--light-purple)"></i>
                    </div>
                    <div class="content">
                       <span>Location</span>
                       <h5><?php echo $_SESSION['user']['location']  ?></h5>
                    </div>
                 </div>

            </div>
               <button class="download-btn"> <i class="fa-solid fa-wrench"></i>  Edit-info</button>
            </div>
       </div>
       


       <div class="postlist">
       <?php foreach ($result1 as $row) {  ?>
       <div class="postcard">
       <img src="../assets/img/<?php echo $row['posts_img'] ?>" alt="">
       </div>
       <?php } ?>
       <div class="postcardadd">
           <img src="../assets/img/add.png" alt="">
       </div>
     
       </div>


       <div class="updatep" id="updatep">
           <img class="close" src="../assets/img/close1.png" alt="">
           <form method="POST" enctype="multipart/form-data">
           <div class="addprofilediv">
             <img class="addprofile" src="../assets/img/addprofile.png" alt="">
             <input required class="addprofilebtn" type="file" name="upimg">
           </div>
           <input class="upbtn" type="submit" name="upbtn" value="update">
           </form>
       </div>

       <div class="updatep" id="addpost">
           <img class="close" id="close" src="../assets/img/close1.png" alt="">
           <form method="POST" enctype="multipart/form-data">
           <div class="addprofilediv">
             <img class="addprofile" src="../assets/img/addpost.webp" alt="">
             <input required class="addprofilebtn" type="file" name="uppost">
           </div>
           <input class="upbtn" type="submit" name="upbtn1" value="Post">
           </form>
       </div>

       <div class="editinfo" id="editinfo">
       <img class="close" id="close1" src="../assets/img/close1.png" alt="">
         <form method="POST">
         <input class="phone_email" type="text" placeholder="phone" name="phone">
         <input class="phone_email" type="text" placeholder="email" name="email">
         <select name="location" class="phone_email" >
         <option value="s" selected disabled hidden><span style="color: gray;">location</span></option>
                    <option value="1.Adrar">1.Adrar</option>
                    <option value="2..Adrar">2.Chlef</option>
                    <option value="3.Laghouat">3.Laghouat</option>
                    <option value="4.Oum El Bouaghi">4.Oum El Bouaghi</option>
                    <option value="5.Batna">5.Batna</option>
                    <option value="6.Béjaïa">6.Béjaïa</option>
                    <option value="7.Biskra">7.Biskra</option>
                    <option value="8.Béchar">8.Béchar</option>
                    <option value="9.Blida">9.Blida</option>
                    <option value="10.Bouira">10.Bouira</option>
                    <option value="11.Tamanrasset">11.Tamanrasset</option>
                    <option value="12.Tébessa">12.Tébessa</option>
                    <option value="13.Tlemcen">13.Tlemcen</option>
                    <option value="14.Tiaret">14.Tiaret</option>
                    <option value="15.Tizi Ouzou">15.Tizi Ouzou</option>
                    <option value="16.Alger">16.Alger</option>
                    <option value="17.Djelfa">17.Djelfa</option>
                    <option value="18.Jijel">18.Jijel</option>
                    <option value="19.Sétif">19.Sétif</option>
                    <option value="20.Saïda">20.Saïda</option>
                    <option value="21.Skikda">21.Skikda</option>
                    <option value="22.Sidi Bel Abbès">22.Sidi Bel Abbès</option>
                    <option value="23.Annaba">23.Annaba</option>
                    <option value="24.Guelma">24.Guelma</option>
                    <option value="25.Constantine">25.Constantine</option>
                    <option value="26.Médéa">26.Médéa</option>
                    <option value="27.Mostaganem">27.Mostaganem</option>
                    <option value="28.M'Sila">28.M'Sila</option>
                    <option value="29.Mascara">29.Mascara</option>
                    <option value="30.Ouargla">30.Ouargla</option>
                    <option value="31.Oran">31.Oran</option>
                    <option value="32.Bayadh">32.El Bayadh</option>
                    <option value="33.Illizi">33.Illizi</option>
                    <option value="34.Bordj Bou Arreridj">34.Bordj Bou Arreridj</option>
                    <option value="35.Boumerdès">35.Boumerdès</option>
                    <option value="36.El Tarf">36.El Tarf</option>
                    <option value="37.Tindouf">37.Tindouf</option>
                    <option value="38.Tissemsilt">38.Tissemsilt</option>
                    <option value="39.El Oued">39.El Oued</option>
                    <option value="40.Khenchela">40.Khenchela</option>
                    <option value="41.Souk Ahras">41.Souk Ahras</option>
                    <option value="42.Tipaza">42.Tipaza</option>
                    <option value="43.Mila">43.Mila</option>
                    <option value="44.Aïn Defla">44.Aïn Defla</option>
                    <option value="45.Naâma">45.Naâma</option>
                    <option value="46.Aïn Témouchent">46.Aïn Témouchent</option>
                    <option value="47.Ghardaïa">47.Ghardaïa</option>
                    <option value="48.Relizane">48.Relizane</option>
         <input type="submit" class="editbtn" value="Edit" name="editbtn">
         </select>
         </form>
       </div>

       <?php 
       $sql2 = "SELECT stat FROM ouvrier WHERE userid = '$id'";
       $result2 = mysqli_query($con, $sql2);
       $result22 = mysqli_fetch_assoc($result2);
       $dd=$result22['stat'];
       echo"$dd";
       if($dd==0){
       echo "<script>
          const staticon = document.querySelector('.staticon');
          staticon.style.backgroundColor ='#770101';
       </script>";}else{
           echo "<script>
          const staticon = document.querySelector('.staticon');
          staticon.style.backgroundColor ='#017736';
       </script>";
       }
       ?>
      
       <?php }else{ 
    header('location:login.php');
  }
    ?>
      
</body>
</html>