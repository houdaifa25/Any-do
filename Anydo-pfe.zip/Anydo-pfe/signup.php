<?php
    include ("conne.php") ;
    session_start();

if (isset($_POST['submit'])){ 
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $password = $_POST['password'];


    $sql = "select * from utilisateur where email ='$email'";
    $result = mysqli_query($con, $sql);
    $count_email = mysqli_num_rows($result);
    $info = mysqli_fetch_assoc($result);




    if ($count_email == 0 ){
        $sql =  " INSERT INTO utilisateur (nom, prenom, password,email) VALUES ('$nom', '$prenom', '$password', '$email') " ;
        $result = mysqli_query($con, $sql);
        if($result){
            
            $sql1 = "SELECT * FROM utilisateur WHERE email ='$email'";
        $result2 = mysqli_query($con, $sql1);
        $info = mysqli_fetch_assoc($result2);

            $_SESSION['user']['ove_or_cl']=0;
            $_SESSION['user']['id']=$info['id'];
            $id=$_SESSION['user']['id'];
            echo  "<script>
            window.location.href='login.php';
                alert('$id');
            </script>";
        
            header("Location:index.php");
        }
    }
    else{
        if($count_email>0){
            echo  '<script>
                window.location.href="login.php";
                alert("email already exists!!");
            </script>' ;
        }



    }

   }
    








   // $sql = " INSERT INTO utilisateur (nom, prenom, password,email)
     //     VALUES ('$nom', '$prenom', '$password', '$email') " ;
 
   // $sql = "  INSERT  INTO `utilisateur` (`nom`, `prenom`, `password`, `email`)
     //        VALUES ('yakoubb', 'bouloudeninee', '123456', 'bouloudeninee@gmail.com') ";
